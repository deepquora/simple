// ───────────────────────────────────────────────────────────────
//  EDIT YOUR LINKS & TEXT HERE
//  The main file to touch for links, brand, and the short labels
//  shown across the site.
// ───────────────────────────────────────────────────────────────

export const SITE = {
  brandName: "Polity Made Simple", // header + footer
  tagline: "Study smarter, learn faster.", // line under the brand name
  initiative: "An initiative by JRF Toppers", // hero eyebrow line
  examLabel: "UGC-NET JRF · December 2026", // highlighted hero tag

  // Your real links:
  telegram: "https://t.me/politicalsciencenetjrfclub",
  whatsapp: "https://chat.whatsapp.com/J8D5WkaJYj0APKBNIY4KhX?s=cl&p=a&ilr=0",
  // If you have a separate WhatsApp *Channel*, paste it here.
  // (Defaults to the group link so nothing is broken.)
  whatsappChannel:
    "https://chat.whatsapp.com/J8D5WkaJYj0APKBNIY4KhX?s=cl&p=a&ilr=0",
  email: "deep.workspace03@gmail.com",
};

// Header navigation. "/#id" links scroll to a homepage section;
// plain paths open another page.
export const NAV_LINKS = [
  { label: "Home", href: "/#home" },
  { label: "Paper 1", href: "/paper-1" },
  { label: "Paper 2", href: "/paper-2" },
  { label: "Mock Tests", href: "/mock-tests" },
  { label: "About Us", href: "/#about" },
  { label: "Contact", href: "/#contact" },
];

// Community channels (Contact section). `brand` picks the colour:
// "telegram" → Telegram blue, "whatsapp" → WhatsApp green.
export const COMMUNITY: {
  label: string;
  desc: string;
  href: string;
  brand: "telegram" | "whatsapp";
}[] = [
  { label: "Telegram Channel", desc: "Notes & updates", href: SITE.telegram, brand: "telegram" },
  { label: "WhatsApp Channel", desc: "Quick alerts", href: SITE.whatsappChannel, brand: "whatsapp" },
  { label: "Discussion Group", desc: "Ask & discuss", href: SITE.whatsapp, brand: "whatsapp" },
];
