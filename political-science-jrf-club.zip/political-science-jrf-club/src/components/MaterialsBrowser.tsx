import { Link } from "react-router-dom";
import { FileText, ExternalLink } from "lucide-react";
import {
  library,
  REAL_TYPES,
  SOON_TYPES,
  type LibraryItem,
} from "../data/library";

type Props = {
  types: string[];
  papers: string[];
  langs: string[];
  setTypes: (v: string[]) => void;
  setPapers: (v: string[]) => void;
  setLangs: (v: string[]) => void;
  onComingSoon: (message: string) => void;
};

const PAPER_ORDER: Record<string, number> = { "Paper 1": 0, "Paper 2": 1 };

function PaperBadge({ paper }: { paper: LibraryItem["paper"] }) {
  const tone =
    paper === "Paper 1" ? "bg-brand/10 text-brand" : "bg-brand-2/10 text-brand-2";
  return (
    <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${tone}`}>
      {paper}
    </span>
  );
}

export default function MaterialsBrowser({
  types,
  papers,
  langs,
  setTypes,
  setPapers,
  setLangs,
  onComingSoon,
}: Props) {
  const toggle = (
    arr: string[],
    val: string,
    setter: (v: string[]) => void
  ) => setter(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);

  const hasFilter = types.length + papers.length + langs.length > 0;

  // No filter → show "latest & essentials". Otherwise → full library.
  const base = hasFilter
    ? library
    : library.filter((i) => i.isNew || i.type === "Syllabus");

  const results = base
    .filter(
      (i) =>
        (types.length === 0 || types.includes(i.type)) &&
        (papers.length === 0 || papers.includes(i.paper)) &&
        (langs.length === 0 || langs.includes(i.language))
    )
    .sort(
      (a, b) =>
        PAPER_ORDER[a.paper] - PAPER_ORDER[b.paper] ||
        a.unit.localeCompare(b.unit) ||
        a.name.localeCompare(b.name)
    );

  const chip = (active: boolean) =>
    "rounded-full border px-3.5 py-1.5 text-sm font-medium transition-all active:scale-95 " +
    (active
      ? "pill-active"
      : "border-edge bg-card text-muted hover:border-brand/40 hover:text-fg");

  return (
    <section id="materials" className="border-t border-edge bg-band">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <p className="eyebrow">Study Material</p>
        <h2 className="mt-1 text-2xl font-extrabold tracking-tight">
          Browse notes, PYQs &amp; more
        </h2>
        <p className="mt-1 text-sm text-muted">
          Tap a category, then narrow by paper or language. One tap opens the PDF.
        </p>

        {/* ── Category chips (real + coming soon) ── */}
        <div className="mt-6 flex flex-wrap gap-2">
          {REAL_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => toggle(types, t, setTypes)}
              className={chip(types.includes(t))}
            >
              {t}
            </button>
          ))}
          {SOON_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => onComingSoon(`${t} — coming soon. Stay tuned!`)}
              className="rounded-full border border-dashed border-edge bg-transparent px-3.5 py-1.5 text-sm font-medium text-muted/70 transition-colors hover:text-muted"
            >
              {t}
              <span className="ml-1.5 font-mono text-[9px] uppercase tracking-wider">
                soon
              </span>
            </button>
          ))}
        </div>

        {/* ── Paper + language sub-filters ── */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="mr-1 text-xs font-semibold uppercase tracking-wider text-muted">
            Filter
          </span>
          {(["Paper 1", "Paper 2"] as const).map((p) => (
            <button
              key={p}
              onClick={() => toggle(papers, p, setPapers)}
              className={chip(papers.includes(p))}
            >
              {p}
            </button>
          ))}
          <span className="mx-1 h-4 w-px bg-edge" />
          {(["English", "Hindi"] as const).map((l) => (
            <button
              key={l}
              onClick={() => toggle(langs, l, setLangs)}
              className={chip(langs.includes(l))}
            >
              {l}
            </button>
          ))}
          {hasFilter && (
            <button
              onClick={() => {
                setTypes([]);
                setPapers([]);
                setLangs([]);
              }}
              className="ml-1 rounded-full px-3 py-1.5 text-sm font-medium text-brand hover:underline"
            >
              Clear
            </button>
          )}
        </div>

        {/* ── Result count ── */}
        <p className="mb-3 mt-6 text-xs font-medium text-muted">
          {hasFilter
            ? `${results.length} ${results.length === 1 ? "material" : "materials"}`
            : "Latest & essentials"}
        </p>

        {/* ── Results ── */}
        {results.length === 0 ? (
          <div className="card p-8 text-center text-sm text-muted">
            No materials match these filters yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
            {results.map((item) => (
              <a
                key={item.url}
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="card-interactive group flex items-center gap-3 p-3"
              >
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand/10 text-brand">
                  <FileText size={16} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">
                    {item.name}
                  </span>
                  <span className="mt-1 flex items-center gap-2">
                    <PaperBadge paper={item.paper} />
                    <span className="text-[11px] text-muted">{item.language}</span>
                    <span className="truncate text-[11px] text-muted">
                      · {item.unit}
                    </span>
                  </span>
                </span>
                {item.isNew && (
                  <span className="shrink-0 rounded bg-brand-2 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    New
                  </span>
                )}
                <ExternalLink
                  size={15}
                  className="shrink-0 text-muted transition-colors group-hover:text-brand"
                />
              </a>
            ))}
          </div>
        )}

        {/* ── Hint to full library ── */}
        <p className="mt-6 text-center text-xs text-muted">
          Looking for everything? Browse the full library on the{" "}
          <Link to="/paper-1" className="font-medium text-brand hover:underline">
            Paper 1
          </Link>{" "}
          and{" "}
          <Link to="/paper-2" className="font-medium text-brand hover:underline">
            Paper 2
          </Link>{" "}
          pages.
        </p>
      </div>
    </section>
  );
}
